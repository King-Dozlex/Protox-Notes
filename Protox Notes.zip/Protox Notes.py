# Imports

import os
import customtkinter
from PIL import Image, ImageTk
import webbrowser
from configparser import ConfigParser
from tkinter import Tk, Frame, Button, Label, RIGHT, X, LEFT, BOTH, Y, BOTTOM, filedialog, Entry
from ctypes import windll
from icoextract import *
import win32com.client  # Import for working with Windows shortcuts
import sys

# Read Contents From Configuration File

configuration_data = ConfigParser()
configuration_data.read("./Assets\\Configuration.ini")

# Create Instance Of App

root = Tk()

# Fake Titlebar

tk_title = "Protox Notes"

# Find Current Monitor Resolution

screen_height = root.winfo_screenheight()
screen_width = root.winfo_screenwidth()

root.title(tk_title) 
root.overrideredirect(True)
root.geometry("410x600")
root.resizable(False, False)
root.iconbitmap("./Assets\\Icons\\Icon.ico")
root.minimized = False
root.maximized = False

root.geometry(str(configuration_data['GUI']['resolution']))

global background_button_colour
background_button_colour = '#121211'

LGRAY = '#3e4042'
DGRAY = '#1c1c1c'
RGRAY = '#121211'

root.config(bg="#25292e")
title_bar = Frame(root, bg=RGRAY, relief='raised', bd=0,highlightthickness=0)

def set_appwindow(mainWindow):
    GWL_EXSTYLE = -20
    WS_EX_APPWINDOW = 0x00040000
    WS_EX_TOOLWINDOW = 0x00000080
    hwnd = windll.user32.GetParent(mainWindow.winfo_id())
    stylew = windll.user32.GetWindowLongW(hwnd, GWL_EXSTYLE)
    stylew = stylew & ~WS_EX_TOOLWINDOW
    stylew = stylew | WS_EX_APPWINDOW
    res = windll.user32.SetWindowLongW(hwnd, GWL_EXSTYLE, stylew)
   
    mainWindow.wm_withdraw()
    mainWindow.after(10, lambda: mainWindow.wm_deiconify())
    
def minimize_me():
    root.attributes("-alpha", 0)
    root.minimized = True  

def deminimize(event):

    root.focus() 
    root.attributes("-alpha", 1)
    
    if root.minimized == True:
        root.minimized = False                              
        
def maximize_me():

    if root.maximized == False:
        root.normal_size = root.geometry()
        expand_button.config(text=" 🗗 ")
        root.geometry("410x600+0+0")
        root.maximized = not root.maximized 
        
    else:
        expand_button.config(text=" 🗖 ")
        root.geometry("410x1000")
        root.maximized = not root.maximized

def close_application():
    open_dimensions = root.winfo_geometry()
    configuration_data['GUI']['resolution'] = str(open_dimensions)
    with open("./Assets\\Configuration.ini", 'w') as f:
        configuration_data.write(f)
    root.destroy()
    sys.exit()
    pass

# Define min and max window size
MIN_WIDTH, MIN_HEIGHT = 410, 600
MAX_WIDTH, MAX_HEIGHT = 900, 1200

close_button = Button(title_bar, text='  x  ', command=close_application,bg=RGRAY,padx=2,pady=2,font=("calibri", 13),bd=0,fg='white',highlightthickness=0)
expand_button = Button(title_bar, text=' 🗖 ', command=maximize_me,bg=RGRAY,padx=2,pady=2,bd=0,fg='white',font=("calibri", 13),highlightthickness=0)
minimize_button = Button(title_bar, text=' 🗕 ',command=minimize_me,bg=RGRAY,padx=2,pady=2,bd=0,fg='white',font=("calibri", 13),highlightthickness=0)
title_bar_title = Label(title_bar, text=tk_title, bg=RGRAY,bd=0,fg='white',font=("helvetica", 10),highlightthickness=0)

window = Frame(root, bg=DGRAY,highlightthickness=0)

title_bar.pack(fill=X)
close_button.pack(side=RIGHT,ipadx=7,ipady=1)
#expand_button.pack(side=RIGHT,ipadx=7,ipady=1)
#minimize_button.pack(side=RIGHT,ipadx=7,ipady=1)
title_bar_title.pack(side=LEFT, padx=10)
window.pack(expand=1, fill=BOTH)

def changex_on_hovering(event):
    global close_button
    close_button['bg']='red'
    
def returnx_to_normalstate(event):
    global close_button
    close_button['bg']=background_button_colour

def change_size_on_hovering(event):
    global expand_button
    expand_button['bg']=LGRAY
    
def return_size_on_hovering(event):
    global expand_button
    expand_button['bg']=background_button_colour
    
def changem_size_on_hovering(event):
    global minimize_button
    minimize_button['bg']='#488ecf'
    
def returnm_size_on_hovering(event):
    global minimize_button
    minimize_button['bg']=background_button_colour
    
def get_pos(event):
    if root.maximized == False:
 
        xwin = root.winfo_x()
        ywin = root.winfo_y()
        startx = event.x_root
        starty = event.y_root

        ywin = ywin - starty
        xwin = xwin - startx

        def move_window(event):
            root.config(cursor="fleur")
            root.geometry(f'+{event.x_root + xwin}+{event.y_root + ywin}')

        def release_window(event):
            root.config(cursor="arrow")
            
        title_bar.bind('<B1-Motion>', move_window)
        title_bar.bind('<ButtonRelease-1>', release_window)
        title_bar_title.bind('<B1-Motion>', move_window)
        title_bar_title.bind('<ButtonRelease-1>', release_window)
    else:
        expand_button.config(text=" 🗖 ")
        root.maximized = not root.maximized

title_bar.bind('<Button-1>', get_pos)
title_bar_title.bind('<Button-1>', get_pos)

close_button.bind('<Enter>',changex_on_hovering)
close_button.bind('<Leave>',returnx_to_normalstate)
expand_button.bind('<Enter>', change_size_on_hovering)
expand_button.bind('<Leave>', return_size_on_hovering)
minimize_button.bind('<Enter>', changem_size_on_hovering)
minimize_button.bind('<Leave>', returnm_size_on_hovering)

resizex_widget = Frame(window,bg=DGRAY,cursor='sb_h_double_arrow')
resizex_widget.pack(side=RIGHT, ipadx=3, fill=Y)

def resizex(event):
    xwin = root.winfo_x()
    new_width = (event.x_root - xwin)
    current_height = root.winfo_height()

    if MIN_WIDTH <= new_width <= MAX_WIDTH:
        root.geometry(f"{new_width}x{current_height}")

resizex_widget.bind("<B1-Motion>",resizex)

resizey_widget = Frame(window,bg=DGRAY,cursor='sb_v_double_arrow')
resizey_widget.pack(side=BOTTOM, padx=3, ipadx=3, fill=X)

def resizey(event):
    ywin = root.winfo_y()
    new_height = (event.y_root - ywin)
    current_width = root.winfo_width()

    if MIN_HEIGHT <= new_height <= MAX_HEIGHT:
        root.geometry(f"{current_width}x{new_height}")

resizey_widget.bind("<B1-Motion>",resizey)

root.bind("<FocusIn>",deminimize) 
root.after(10, lambda: set_appwindow(root))
#root.after(0, maximize_me)

################################################################################# ALL Starting Objects ###########################################################################################

overlap_state = customtkinter.IntVar(value=0)

settings_cog_image_import = Image.open("./Assets\\Icons\\Settings Cog.png").resize((50, 50))
settings_cog_tk_image = ImageTk.PhotoImage(settings_cog_image_import)

back_arrow_image_import = Image.open("./Assets\\Icons\\Back Arrow.png").resize((50, 50))
back_arrow_tk_image = ImageTk.PhotoImage(back_arrow_image_import)

edit_note_window = customtkinter.CTkToplevel()
edit_note_window.withdraw()
edit_note_window.overrideredirect(True)

if configuration_data['GUI']['theme_colour'] == 'Blue':
    colour_list_for_theme = ['Blue', 'Red', 'Green', 'Purple', 'Yellow', 'Cyan', 'Default']
elif configuration_data['GUI']['theme_colour'] == 'Red':
    colour_list_for_theme = ['Red', 'Blue', 'Green', 'Purple', 'Yellow', 'Cyan', 'Default']
elif configuration_data['GUI']['theme_colour'] == 'Green':
    colour_list_for_theme = ['Green', 'Blue', 'Red', 'Purple', 'Yellow', 'Cyan', 'Default']
elif configuration_data['GUI']['theme_colour'] == 'Purple':
    colour_list_for_theme = ['Purple', 'Blue', 'Green', 'Red', 'Yellow', 'Cyan', 'Default']
elif configuration_data['GUI']['theme_colour'] == 'Yellow':
    colour_list_for_theme = ['Yellow', 'Blue', 'Green', 'Purple', 'Red', 'Cyan', 'Default']
elif configuration_data['GUI']['theme_colour'] == 'Cyan':
    colour_list_for_theme = ['Cyan', 'Blue', 'Green', 'Purple', 'Yellow', 'Red', 'Default']
elif configuration_data['GUI']['theme_colour'] == 'Cyan':
    colour_list_for_theme = ['Default', 'Cyan', 'Blue', 'Green', 'Purple', 'Yellow', 'Red']
else:
    pass

################################################################################# ALL FUNCTIONS ###########################################################################################

def update_settings_image(event=None):
    global settings_button
    # Get a % of window width or height for dynamic size
    size = min(root.winfo_width(), root.winfo_height()) // 10  # Adjust divisor for scaling
    size = max(16, size)  # Minimum size to avoid too small

    resized_img = settings_cog_image_import.resize((size, size), Image.LANCZOS)
    resized_img2 = back_arrow_image_import.resize((size, size), Image.LANCZOS)
    tk_image = customtkinter.CTkImage(resized_img, size=(size, size))
    tk_image2 = customtkinter.CTkImage(resized_img2, size=(size, size))
    settings_button.configure(image=tk_image)
    main_notes_app_button.configure(image=tk_image2)
    settings_button.image = tk_image  # Keep reference to avoid garbage collection
    main_notes_app_button.image = tk_image2

def settings_page():
    try:
        theme_colour_button_default.place_forget()
        theme_colour_button_blue.place_forget()
        theme_colour_button_red.place_forget()
        theme_colour_button_yellow.place_forget()
        theme_colour_button_purple.place_forget()
        theme_colour_button_green.place_forget()
        theme_colour_button_cyan.place_forget()
        gui_colour_label.place_forget()
        options_colour_button.configure(text='Colours', command=colour_selection_function)
    except:
        pass
    options_colour_button.place_forget()
    settings_button.place_forget()
    main_textbox.place_forget()
    edit_note_button.place_forget()
    reset_app_position_button.place(relx=0.5, rely=0.25, anchor='center', relheight=0.2, relwidth=0.5)
    button_for_overlay.place(relx=0.5, rely=0.75, anchor='center', relheight=0.2, relwidth=0.5)
    main_notes_app_button.place(relx=0.9, rely=0.925, anchor='center', relwidth=0.1, relheight=0.1)
    pass

def restore_notes_app():
    try:
        theme_colour_button_default.place_forget()
        theme_colour_button_blue.place_forget()
        theme_colour_button_red.place_forget()
        theme_colour_button_yellow.place_forget()
        theme_colour_button_purple.place_forget()
        theme_colour_button_green.place_forget()
        theme_colour_button_cyan.place_forget()
        gui_colour_label.place_forget()
        options_colour_button.configure(text='Colours', command=colour_selection_function)
    except:
        pass
    main_notes_app_button.place_forget()
    button_for_overlay.place_forget()
    reset_app_position_button.place_forget()
    main_textbox.place(relx=0.5, rely=0.45, anchor="center", relwidth=0.9, relheight=0.8)
    settings_button.place(relx=0.9, rely=0.925, anchor='center', relwidth=0.1, relheight=0.1)
    edit_note_button.place(relx=0.25, rely=0.925, anchor="center", relwidth=0.4, relheight=0.1)
    options_colour_button.place(relx=0.65, rely=0.925, anchor="center", relwidth=0.3, relheight=0.1)

def change_overlap_state():
    if overlap_state.get() == 1:
        overlap_state.set(0)
        root.attributes('-topmost', 1)
        button_for_overlay.configure(text='Turn Overlap Off')
        configuration_data['Features']['overlap_state'] = 'On'
        with open("./Assets\\Configuration.ini", "w") as f:
            configuration_data.write(f)
    elif overlap_state.get() == 0:
        overlap_state.set(1)
        root.attributes('-topmost', 0)
        button_for_overlay.configure(text='Turn Overlap On')
        configuration_data['Features']['overlap_state'] = 'Off'
        with open("./Assets\\Configuration.ini", "w") as f:
            configuration_data.write(f)
    else:
        pass
    pass

def overlap_state_on():
    root.attributes('-topmost', 1)
    button_for_overlay.configure(text='Turn Overlap Off', command=overlap_state_off)
    configuration_data['Features']['overlap_state'] = 'On'
    with open("./Assets\\Configuration.ini", "w") as f:
        configuration_data.write(f)
    pass

def overlap_state_off():
    root.attributes('-topmost', 0)
    button_for_overlay.configure(text='Turn Overlap On', command=overlap_state_on)
    configuration_data['Features']['overlap_state'] = 'Off'
    with open("./Assets\\Configuration.ini", "w") as f:
        configuration_data.write(f)
    pass

def edit_note():
    root.withdraw()
    edit_note_window.deiconify()
    edit_textbox.delete('0.0', "end")
    current_dimensions = str(root.winfo_geometry())
    edit_note_window.geometry(current_dimensions)
    edit_textbox.insert('0.0', str(configuration_data['Textbox']['contents']))
    pass

def confirm_changed_to_note():
    contents = str(edit_textbox.get('0.0', "end"))
    edit_note_window.withdraw()
    root.deiconify()
    changed_dimensions = str(edit_note_window.winfo_geometry())
    root.geometry(changed_dimensions)
    main_textbox.delete('0.0', "end")
    main_textbox.insert('0.0', contents)
    configuration_data['Textbox']['contents'] = contents
    with open("./Assets\\Configuration.ini", 'w') as f:
        configuration_data.write(f)
    pass

def clear_note():
    edit_textbox.delete('0.0', "end")

def cancel_changes_to_note():
    edit_note_window.withdraw()
    root.deiconify()
    pass

def hide_window():
    root.attributes('-alpha', 0)
    pass

def default_hide_window(event):
    root.attributes('-alpha', 0)
    pass

def show_window(event):
    root.attributes('-alpha', 1)
    pass

def reset_app_position():
    try:
        gui_colour_label.place_forget()
        options_colour_button.configure(text='Colours', command=colour_selection_function)
        main_textbox.place(relx=0.5, rely=0.45, anchor="center", relwidth=0.9, relheight=0.8)
        root.after(0, restore_notes_app)
        theme_colour_button_default.place_forget()
        theme_colour_button_blue.place_forget()
        theme_colour_button_red.place_forget()
        theme_colour_button_yellow.place_forget()
        theme_colour_button_purple.place_forget()
        theme_colour_button_green.place_forget()
        theme_colour_button_cyan.place_forget()
    except:
        pass
    root.geometry("410x600+0+0")
    configuration_data['GUI']['resolution'] = '410x600+0+0'
    with open("./Assets\\Configuration.ini", 'w') as f:
        configuration_data.write(f)
    pass

def update_font_size(event=None):
    window_height = root.winfo_height()
    # Scale font size based on height, and clamp it to a usable range
    font_size = max(10, min(20, window_height // 30))  # Adjust the divisor as needed

    new_font = customtkinter.CTkFont(size=font_size)
    edit_note_button.configure(font=new_font)
    button_for_overlay.configure(font=new_font)
    reset_app_position_button.configure(font=new_font)
    options_colour_button.configure(font=new_font)
    gui_colour_label.configure(font=new_font)
    theme_colour_button_default.configure(font=new_font)
    theme_colour_button_blue.configure(font=new_font)
    theme_colour_button_purple.configure(font=new_font)
    theme_colour_button_red.configure(font=new_font)
    theme_colour_button_green.configure(font=new_font)
    theme_colour_button_cyan.configure(font=new_font)
    theme_colour_button_yellow.configure(font=new_font)
    confirm_changed_button.configure(font=new_font)
    cancel_changes_button.configure(font=new_font)
    clear_note_button.configure(font=new_font)

def on_window_resize(event=None):
    update_settings_image()
    update_font_size()

def confirm_changed_text_colour():
    options_colour_button.configure(command=colour_selection_function, text='Colours')
    main_textbox.place(relx=0.5, rely=0.45, anchor="center", relwidth=0.9, relheight=0.8)
    
    # Hide Widgets
    gui_colour_label.place_forget()
    theme_colour_button_default.place_forget()
    theme_colour_button_blue.place_forget()
    theme_colour_button_red.place_forget()
    theme_colour_button_green.place_forget()
    theme_colour_button_purple.place_forget()
    theme_colour_button_cyan.place_forget()
    theme_colour_button_yellow.place_forget()
    pass

def colour_selection_function():
    # Configure Button To Go Back To Main Page
    options_colour_button.configure(command=confirm_changed_text_colour, text='Confirm')
    
    # Configure Size Of Main Textbox
    main_textbox.place(rely=0.2, relheight=0.3)
    
    # Place Theme Label
    gui_colour_label.place(relx=0.5, rely=0.4, anchor='center', relheight=0.1, relwidth=0.3)

    # Place Button Colours For GUI
    theme_colour_button_blue.place(relx=0.25, rely=0.505, anchor='center', relwidth=0.3, relheight=0.075)
    theme_colour_button_red.place(relx=0.25, rely=0.605, anchor='center', relwidth=0.3, relheight=0.075)
    theme_colour_button_green.place(relx=0.25, rely=0.705, anchor='center', relwidth=0.3, relheight=0.075)
    theme_colour_button_purple.place(relx=0.75, rely=0.505, anchor='center', relwidth=0.3, relheight=0.075)
    theme_colour_button_yellow.place(relx=0.75, rely=0.605, anchor='center', relwidth=0.3, relheight=0.075)
    theme_colour_button_cyan.place(relx=0.75, rely=0.705, anchor='center', relwidth=0.3, relheight=0.075)
    theme_colour_button_default.place(relx=0.5, rely=0.8, anchor='center', relwidth=0.8, relheight=0.075)
    pass

def blue_colour_theme():
    configuration_data['GUI']['theme_colour'] = 'Blue'
    with open("./Assets\\Configuration.ini", 'w') as f:
        configuration_data.write(f)
    
    global background_button_colour
    background_button_colour = '#1ea4e3'
    for x in list_of_affected_widgets:
        try:
            x.configure(fg_color='#1ea4e3', hover_color='#00d9d9')
        except:
            title_bar.config(bg='#1ea4e3')
            title_bar_title.config(bg='#1ea4e3')
            close_button.config(bg='#1ea4e3')
            pass
    pass

def red_colour_theme():
    configuration_data['GUI']['theme_colour'] = 'Red'
    with open("./Assets\\Configuration.ini", 'w') as f:
        configuration_data.write(f)

    global background_button_colour
    background_button_colour = '#b70036'
    for x in list_of_affected_widgets:
        try:
            x.configure(fg_color='#b70036', hover_color='#e3507a')
        except:
            title_bar.config(bg='#b70036')
            title_bar_title.config(bg='#b70036')
            close_button.config(bg='#b70036')
            pass
    pass

def green_colour_theme():
    configuration_data['GUI']['theme_colour'] = 'Green'
    with open("./Assets\\Configuration.ini", 'w') as f:
        configuration_data.write(f)

    global background_button_colour
    background_button_colour = '#63ca00'
    for x in list_of_affected_widgets:
        try:
            x.configure(fg_color='#63ca00', hover_color='#4ee44e')
        except:
            title_bar.config(bg='#63ca00')
            title_bar_title.config(bg='#63ca00')
            close_button.config(bg='#63ca00')
            pass
    pass

def purple_colour_theme():
    configuration_data['GUI']['theme_colour'] = 'Purple'
    with open("./Assets\\Configuration.ini", 'w') as f:
        configuration_data.write(f)
    
    global background_button_colour
    background_button_colour = '#ad2fff'
    for x in list_of_affected_widgets:
        try:
            x.configure(fg_color='#ad2fff', hover_color='#b72fb2')
        except:
            title_bar.config(bg='#ad2fff')
            title_bar_title.config(bg='#ad2fff')
            close_button.config(bg='#ad2fff')
            pass
    pass

def yellow_colour_theme():
    configuration_data['GUI']['theme_colour'] = 'Yellow'
    with open("./Assets\\Configuration.ini", 'w') as f:
        configuration_data.write(f)
    
    global background_button_colour
    background_button_colour = '#ccbb00'
    for x in list_of_affected_widgets:
        try:
            x.configure(fg_color='#ccbb00', hover_color='#ffff14')
        except:
            title_bar.config(bg='#ccbb00')
            title_bar_title.config(bg='#ccbb00')
            close_button.config(bg='#ccbb00')
            pass
    pass

def cyan_colour_theme():
    configuration_data['GUI']['theme_colour'] = 'Cyan'
    with open("./Assets\\Configuration.ini", 'w') as f:
        configuration_data.write(f)

    global background_button_colour
    background_button_colour = '#24c1e9'
    for x in list_of_affected_widgets:
        try:
            x.configure(fg_color='#24c1e9', hover_color='#47cbec')
        except:
            title_bar.config(bg='#24c1e9')
            title_bar_title.config(bg='#24c1e9')
            close_button.config(bg='#24c1e9')
            pass
    pass

def default_colour_theme():
    configuration_data['GUI']['theme_colour'] = 'Default'
    with open("./Assets\\Configuration.ini", 'w') as f:
        configuration_data.write(f)
    
    global background_button_colour
    background_button_colour = '#121211'
    for x in list_of_affected_widgets:
        try:
            x.configure(fg_color='#212121', hover_color='#0b0b0b')
        except:
            title_bar.config(bg='#121211')
            title_bar_title.config(bg='#121211')
            close_button.config(bg='#121211')
            pass
    pass

################################################################################## Start Construction ####################################################################################

button_for_overlay = customtkinter.CTkButton(window, text='Turn Overlap On', command=change_overlap_state, fg_color='#212121', hover_color='#0b0b0b')
reset_app_position_button = customtkinter.CTkButton(window, text='Reset Position', fg_color='#212121', hover_color='#0b0b0b', command=reset_app_position)

global settings_button
settings_button = customtkinter.CTkButton(window, image=settings_cog_tk_image,text='', fg_color='#1c1c1c', hover_color='#1c1c1c', command=settings_page, width=80, height=80)
settings_button.place(relx=0.9, rely=0.925, anchor='center', relwidth=0.1, relheight=0.1)

main_textbox = customtkinter.CTkTextbox(window)
main_textbox.place(relx=0.5, rely=0.45, anchor="center", relwidth=0.9, relheight=0.8)
main_textbox.insert('0.0', str(configuration_data['Textbox']['contents']))

edit_note_button = customtkinter.CTkButton(window, text='Edit Note', fg_color='#212121', hover_color='#0b0b0b', height=45, command=edit_note, font=('Helvetica', 20))
edit_note_button.place(relx=0.25, rely=0.925, anchor="center", relwidth=0.4, relheight=0.1)

confirm_changed_button = customtkinter.CTkButton(edit_note_window, text='Confirm', fg_color='#1c1c1c', hover_color='#0b0b0b', command=confirm_changed_to_note)
confirm_changed_button.place(relx=0.25, rely=0.9, anchor='center', relwidth=0.2, relheight=0.1)
cancel_changes_button = customtkinter.CTkButton(edit_note_window, text='Cancel', fg_color='#1c1c1c', hover_color='#0b0b0b', command=cancel_changes_to_note)
cancel_changes_button.place(relx=0.75, rely=0.9, anchor='center', relwidth=0.2, relheight=0.1)
clear_note_button = customtkinter.CTkButton(edit_note_window, text='Clear', fg_color='#1c1c1c', hover_color='#0b0b0b', command=clear_note)
clear_note_button.place(relx=0.5, rely=0.9, anchor='center', relwidth=0.2, relheight=0.1)
edit_textbox = customtkinter.CTkTextbox(edit_note_window, height=450, width=380)
edit_textbox.place(relx=0.5, rely=0.425, anchor='center', relwidth=0.9, relheight=0.8)
edit_textbox.insert("0.0", str(configuration_data['Textbox']['contents']))

options_colour_button = customtkinter.CTkButton(window, text='Colours', fg_color='#212121', hover_color='#0b0b0b', height=45, font=('Helvetica', 20), command=colour_selection_function)
options_colour_button.place(relx=0.65, rely=0.925, anchor="center", relwidth=0.3, relheight=0.1)

# Theme Settings

gui_colour_label = customtkinter.CTkLabel(window, text='GUI Colour:', font=('Roboto', 14))

theme_colour_button_blue = customtkinter.CTkButton(window, text='Blue', font=('Roboto', 11), fg_color='#1ea4e3', hover_color='#00d9d9', command=blue_colour_theme)
theme_colour_button_red = customtkinter.CTkButton(window, text='Red', font=('Roboto', 11), fg_color='#b70036', hover_color='#e3507a', command=red_colour_theme)
theme_colour_button_green = customtkinter.CTkButton(window, text='Green', font=('Roboto', 11), fg_color='#63ca00', hover_color='#4ee44e', command=green_colour_theme)
theme_colour_button_purple = customtkinter.CTkButton(window, text='Purple', font=('Roboto', 11), fg_color='#ad2fff', hover_color='#b72fb2', command=purple_colour_theme)
theme_colour_button_yellow = customtkinter.CTkButton(window, text='Yellow', font=('Roboto', 11), fg_color='#ccbb00', hover_color='#ffff14', command=yellow_colour_theme)
theme_colour_button_cyan = customtkinter.CTkButton(window, text='Cyan', font=('Roboto', 11), fg_color='#24c1e9', hover_color='#47cbec', command=cyan_colour_theme)
theme_colour_button_default = customtkinter.CTkButton(window, text='Default', font=('Roboto', 11), fg_color='#212121', hover_color='#0b0b0b', command=default_colour_theme)

list_of_affected_widgets = [edit_note_button, options_colour_button, reset_app_position_button, button_for_overlay, title_bar, confirm_changed_button, clear_note_button, cancel_changes_button]

root.bind("<H>", default_hide_window)
root.bind("<S>", show_window)
root.bind("<Configure>", on_window_resize)

main_notes_app_button = customtkinter.CTkButton(window, image=back_arrow_tk_image, text='', fg_color='#1c1c1c', hover_color='#1c1c1c', command=restore_notes_app, width=25)

# INTERESTING IDEA customize_hide_window_keybind = customtkinter.CTkButton(window, text='Hide Window Keybind', command=edit_hide_window_keybind, fg_color='#1c1c1c', hover_color='#0b0b0b')

# IF YOUR GOING TO ADD MULTIPLE NOTES: Add a 'change note' button in settings and have it bring up a page where they can rename/select a note they would want alll you would do is swap out the 'main_textbox' and 'edit_textbox' contents with whatever is in the note they selected.

# On Start-Up (Lazy Edition)

if configuration_data['Features']['overlap_state'] == 'Off':
    root.after(0, overlap_state_off)
elif configuration_data['Features']['overlap_state'] == 'On':
    root.after(0, overlap_state_on)
else:
    pass

if configuration_data['GUI']['theme_colour'] == 'Blue':
    root.after(0, blue_colour_theme)
elif configuration_data['GUI']['theme_colour'] == 'Red':
    root.after(0, red_colour_theme)
elif configuration_data['GUI']['theme_colour'] == 'Green':
    root.after(0, green_colour_theme)
elif configuration_data['GUI']['theme_colour'] == 'Purple':
    root.after(0, purple_colour_theme)
elif configuration_data['GUI']['theme_colour'] == 'Yellow':
    root.after(0, yellow_colour_theme)
elif configuration_data['GUI']['theme_colour'] == 'Cyan':
    root.after(0, cyan_colour_theme)
elif configuration_data['GUI']['theme_colour'] == 'Default':
    root.after(0, default_colour_theme)
else:
    root.after(0, default_colour_theme)
    pass

################################################################################## End Construction ######################################################################################

root.mainloop()